﻿using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using IronXL;

namespace IronXL_vs_NPOI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void ReadExcelNPOI()
        {
            DataTable dtTable = new DataTable();

            List<string> lstRows = new List<string>();
            ISheet objWorksheet;

            string strPath = @"c:\temp\NPOI_Test.XLSX";

            using (var fStream = new FileStream(strPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                fStream.Position = 0;
                XSSFWorkbook objWorkbook = new XSSFWorkbook(fStream);

                objWorksheet = objWorkbook.GetSheetAt(0);
                IRow objHeader = objWorksheet.GetRow(0);
                int countCells = objHeader.LastCellNum;

                for (int j = 0; j < countCells; j++)
                {
                    ICell objCell = objHeader.GetCell(j);
                    if (objCell == null || string.IsNullOrWhiteSpace(objCell.ToString())) continue;
                    {
                        dtTable.Columns.Add(objCell.ToString());
                    }
                }
                for (int i = (objWorksheet.FirstRowNum + 1); i <= objWorksheet.LastRowNum; i++)
                {
                    IRow objRow = objWorksheet.GetRow(i);

                    if (objRow == null) continue;

                    if (objRow.Cells.All(d => d.CellType == CellType.Blank)) continue;

                    for (int j = objRow.FirstCellNum; j < countCells; j++)
                    {
                        if (objRow.GetCell(j) != null)
                        {
                            if (!string.IsNullOrEmpty(objRow.GetCell(j).ToString()) && !string.IsNullOrWhiteSpace(objRow.GetCell(j).ToString()))
                            {
                                lstRows.Add(objRow.GetCell(j).ToString());
                            }
                        }
                    }

                    if (lstRows.Count > 0)
                        dtTable.Rows.Add(lstRows.ToArray());
                    lstRows.Clear();
                }
            }

            dataGridView1.DataSource = dtTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReadExcelNPOI();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string strPath = @"c:\temp\NPOI_Test.XLSX";

            WorkBook workbook = WorkBook.Load(strPath);
            WorkSheet sheet = workbook.DefaultWorkSheet;

            var dtTable = sheet.ToDataTable(true);

            dataGridView1.DataSource = dtTable;
 
        }
    }
}
